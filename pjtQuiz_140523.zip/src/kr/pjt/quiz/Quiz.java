package kr.pjt.quiz;

public class Quiz{
	int nid;
	String category;
	String question;
	String example01;
	String example02;
	String example03;
	String example04;
	String answer01;
	String answer02;
	String answer03;
	String answer04;
	String hint;
	
}

