package kr.pjt.quiz;

import android.app.Activity;

public class SearchActivity extends Activity{

}
