/** Automatically generated file. DO NOT MODIFY */
package kr.pjt.quiz;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}